# explore.grodno

## Pre-requisites

 - node/npm

## Install

    npm i
    npm start

## Local Use

    open `http://localhost:8086` in your browser