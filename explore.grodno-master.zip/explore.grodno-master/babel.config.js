const presets = [
    [
        "env",
    ],
];

const plugins = [
    "transform-runtime",
    "transform-class-properties",
    "transform-object-rest-spread"
];

const ignore = [];
module.exports = {
    plugins,
    presets,
    ignore,
};